var ffs_definition = context.getVariable('private.ffs_definition');
var output_name = context.getVariable("output_name");
 
context.setVariable(output_name, ffs_definition);